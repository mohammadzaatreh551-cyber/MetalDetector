package com.metaldetector

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.*
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var magnetSensor: Sensor? = null

    // Views
    private lateinit var tvStatus: TextView
    private lateinit var tvStatusSub: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvDepth: TextView
    private lateinit var tvX: TextView
    private lateinit var tvY: TextView
    private lateinit var tvZ: TextView
    private lateinit var progressTotal: ProgressBar
    private lateinit var progressMetal: ProgressBar
    private lateinit var progressVoid: ProgressBar
    private lateinit var tvMetalDepth: TextView
    private lateinit var tvVoidDepth: TextView
    private lateinit var btnStart: Button
    private lateinit var seekMetal: SeekBar
    private lateinit var seekVoid: SeekBar
    private lateinit var tvMetalThresh: TextView
    private lateinit var tvVoidThresh: TextView
    private lateinit var cardMain: androidx.cardview.widget.CardView
    private lateinit var tvSensorInfo: TextView

    private var running = false
    private var baseValue: Double? = null
    private var metalThreshold = 500
    private var voidThreshold = 100

    // لتنعيم القراءات
    private val smoothX = FloatArray(5)
    private val smoothY = FloatArray(5)
    private val smoothZ = FloatArray(5)
    private var smoothIdx = 0

    private val vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        else
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        bindViews()
        setupSensor()
        setupSliders()
        setupButton()
    }

    private fun bindViews() {
        tvStatus      = findViewById(R.id.tvStatus)
        tvStatusSub   = findViewById(R.id.tvStatusSub)
        tvTotal       = findViewById(R.id.tvTotal)
        tvDepth       = findViewById(R.id.tvDepth)
        tvX           = findViewById(R.id.tvX)
        tvY           = findViewById(R.id.tvY)
        tvZ           = findViewById(R.id.tvZ)
        progressTotal = findViewById(R.id.progressTotal)
        progressMetal = findViewById(R.id.progressMetal)
        progressVoid  = findViewById(R.id.progressVoid)
        tvMetalDepth  = findViewById(R.id.tvMetalDepth)
        tvVoidDepth   = findViewById(R.id.tvVoidDepth)
        btnStart      = findViewById(R.id.btnStart)
        seekMetal     = findViewById(R.id.seekMetal)
        seekVoid      = findViewById(R.id.seekVoid)
        tvMetalThresh = findViewById(R.id.tvMetalThresh)
        tvVoidThresh  = findViewById(R.id.tvVoidThresh)
        cardMain      = findViewById(R.id.cardMain)
        tvSensorInfo  = findViewById(R.id.tvSensorInfo)
    }

    private fun setupSensor() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        // نجرب كل أنواع حساسات المغناطيسية
        magnetSensor = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED)

        if (magnetSensor != null) {
            tvSensorInfo.text = "✅ حساس: ${magnetSensor!!.name}"
            tvSensorInfo.setTextColor(ContextCompat.getColor(this, R.color.green))
        } else {
            tvSensorInfo.text = "❌ لم يُعثر على حساس مغناطيسي"
            tvSensorInfo.setTextColor(ContextCompat.getColor(this, R.color.red))
            btnStart.isEnabled = false
        }
    }

    private fun setupSliders() {
        seekMetal.max = 1950
        seekMetal.progress = 450   // = 500µT (offset 50)
        tvMetalThresh.text = "500"

        seekVoid.max = 390
        seekVoid.progress = 90    // = 100µT (offset 10)
        tvVoidThresh.text = "100"

        seekMetal.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                metalThreshold = p + 50
                tvMetalThresh.text = metalThreshold.toString()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        seekVoid.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, u: Boolean) {
                voidThreshold = p + 10
                tvVoidThresh.text = voidThreshold.toString()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun setupButton() {
        btnStart.setOnClickListener {
            if (running) stopDetection() else startDetection()
        }
    }

    private fun startDetection() {
        baseValue = null
        smoothIdx = 0
        running = true
        sensorManager.registerListener(this, magnetSensor, SensorManager.SENSOR_DELAY_FASTEST)
        btnStart.text = "⏹ إيقاف"
        btnStart.setBackgroundColor(ContextCompat.getColor(this, R.color.red))
        tvStatus.text = "🔄 يعمل..."
        tvStatusSub.text = "جاري معايرة الخلفية..."
    }

    private fun stopDetection() {
        running = false
        sensorManager.unregisterListener(this)
        btnStart.text = "▶ ابدأ الكشف"
        btnStart.setBackgroundColor(ContextCompat.getColor(this, R.color.green))
        tvStatus.text = "موقوف"
        tvStatus.setTextColor(ContextCompat.getColor(this, R.color.muted))
        tvStatusSub.text = "اضغط ابدأ للاستمرار"
        cardMain.setCardBackgroundColor(ContextCompat.getColor(this, R.color.card))
        tvDepth.text = "— متر"
        tvDepth.setTextColor(ContextCompat.getColor(this, R.color.muted))
        progressMetal.progress = 0
        progressVoid.progress = 0
        tvMetalDepth.text = "—"
        tvVoidDepth.text = "—"
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!running) return

        // تنعيم Moving Average
        smoothX[smoothIdx % 5] = event.values[0]
        smoothY[smoothIdx % 5] = event.values[1]
        smoothZ[smoothIdx % 5] = event.values[2]
        smoothIdx++
        if (smoothIdx < 5) return

        val x = smoothX.average()
        val y = smoothY.average()
        val z = smoothZ.average()
        val total = sqrt(x*x + y*y + z*z)

        // معايرة الخلفية (أول 20 قراءة)
        if (baseValue == null) {
            baseValue = total
            tvStatusSub.text = "تمت المعايرة ✓"
            return
        }

        val diff = abs(total - baseValue!!)
        val depth = estimateDepth(diff)

        runOnUiThread {
            // تحديث المحاور
            tvX.text = String.format("%.1f", x)
            tvY.text = String.format("%.1f", y)
            tvZ.text = String.format("%.1f", z)
            tvTotal.text = String.format("%.1f µT", total)

            // شريط كلي
            val pct = ((total / (metalThreshold * 1.5)) * 100).coerceIn(0.0, 100.0).toInt()
            progressTotal.progress = pct

            when {
                diff > metalThreshold -> showMetal(depth)
                total < voidThreshold -> showVoid(depth)
                else -> showNormal()
            }
        }
    }

    private fun estimateDepth(diff: Double): String {
        if (diff < 10) return "—"
        val k = 500.0
        val d = (k / diff).coerceIn(0.1, 10.0)
        return String.format("%.1f", d)
    }

    private fun showMetal(depth: String) {
        val red = ContextCompat.getColor(this, R.color.red)
        tvStatus.text = "🔴 يوجد معدن!"
        tvStatus.setTextColor(red)
        tvStatusSub.text = "إشارة قوية — معدن مكتشف"
        cardMain.setCardBackgroundColor(ContextCompat.getColor(this, R.color.card_red))
        tvDepth.text = "$depth متر"
        tvDepth.setTextColor(red)
        tvMetalDepth.text = if (depth != "—") "${depth}م" else "—"
        tvVoidDepth.text = "—"
        if (depth != "—") {
            val depthF = depth.toFloatOrNull() ?: 10f
            progressMetal.progress = ((10f - depthF) / 10f * 100f + 10f).toInt().coerceIn(0, 100)
        }
        progressVoid.progress = 0
        // اهتزاز
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0,200,100,200), -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0,200,100,200), -1)
        }
    }

    private fun showVoid(depth: String) {
        val blue = ContextCompat.getColor(this, R.color.blue)
        tvStatus.text = "🔵 يوجد فراغ!"
        tvStatus.setTextColor(blue)
        tvStatusSub.text = "إشارة ضعيفة — تجويف أو كهف محتمل"
        cardMain.setCardBackgroundColor(ContextCompat.getColor(this, R.color.card_blue))
        tvDepth.text = "$depth متر"
        tvDepth.setTextColor(blue)
        tvVoidDepth.text = if (depth != "—") "${depth}م" else "—"
        tvMetalDepth.text = "—"
        if (depth != "—") {
            val depthF = depth.toFloatOrNull() ?: 10f
            progressVoid.progress = ((10f - depthF) / 10f * 100f + 10f).toInt().coerceIn(0, 100)
        }
        progressMetal.progress = 0
        vibrator.cancel()
    }

    private fun showNormal() {
        val green = ContextCompat.getColor(this, R.color.green)
        tvStatus.text = "🟢 أرض طبيعية"
        tvStatus.setTextColor(green)
        tvStatusSub.text = "لا يوجد شيء غير عادي"
        cardMain.setCardBackgroundColor(ContextCompat.getColor(this, R.color.card))
        tvDepth.text = "— متر"
        tvDepth.setTextColor(ContextCompat.getColor(this, R.color.muted))
        tvMetalDepth.text = "—"
        tvVoidDepth.text = "—"
        progressMetal.progress = 0
        progressVoid.progress = 0
        vibrator.cancel()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onPause() {
        super.onPause()
        if (running) sensorManager.unregisterListener(this)
    }

    override fun onResume() {
        super.onResume()
        if (running) sensorManager.registerListener(this, magnetSensor, SensorManager.SENSOR_DELAY_FASTEST)
    }

    override fun onDestroy() {
        super.onDestroy()
        vibrator.cancel()
    }
}
